package com.qyntrixg.pro;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class ShizukuService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
