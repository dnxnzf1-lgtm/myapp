package com.qyntrixg.pro;

import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import rikka.shizuku.Shizuku;

public class ShizukuSafe {

    public static void runSafe(Runnable runnable) {

        new Handler(Looper.getMainLooper()).postDelayed(() -> {

            try {

                if (!Shizuku.pingBinder()) {
                    return;
                }

                if (Shizuku.isPreV11() ||
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {

                    runnable.run();

                } else {
                    Shizuku.requestPermission(1001);
                }

            } catch (Throwable ignored) {}

        }, 1500);
    }
}
