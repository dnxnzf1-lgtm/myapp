import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

export type Lang = "en" | "ar";

const TRANSLATIONS = {
  en: {
    appName: "QyntrixG",
    dashboardTab: "Home",
    pathsTab: "Paths",
    boostTab: "Boost",
    dnsTab: "DNS",
    settingsTab: "Settings",

    splashGreeting: "Welcome to the Gamers Republic",
    splashGreetingAr: "",
    splashSub: "AI · DoH · Multi-Path · Shizuku",
    splashVersion: "v2.0 ULTRA",
    splashBrand: "POWERED BY SHIZUKU · ROOT BRIDGE",
    splashInit: "Initializing AI Engine...",
    splashScanSub: "Analyzing 15 Paths · 5 DNS Nodes",

    dashboard: "Network Dashboard",
    connectionQuality: "Connection Quality",
    excellent: "Excellent",
    good: "Good",
    fair: "Fair",
    poor: "Poor",
    aiOn: "AI ON",
    aiOff: "AI OFF",
    ping: "PING",
    loss: "LOSS",
    jitter: "JITTER",
    download: "DOWN",
    upload: "UP",
    startOptimizer: "START OPTIMIZER",
    optimizing: "OPTIMIZING",
    tapToStop: "Tap to stop · AI actively routing",
    tapToEnable: "Tap to enable AI network boost",
    activePath: "ACTIVE PATH",
    aiEventLog: "AI Event Log",
    noEvents: "No events yet. Start optimizing.",
    root: "ROOT",
    noRoot: "NO ROOT",
    aiConnectionActive: "AI Connection Active",
    activeAiSub: "Monitoring 15 paths in real-time",
    waveformLabel: "NETWORK WAVEFORM",
    runDiscovery: "Run Best-Path Discovery",

    // Game Engine
    addGame: "Add Game",
    addGameSub: "Deep optimize a specific game · port bridge · AI routing",
    gameLibrary: "GAME LIBRARY",
    gameLibrarySub: "Select a game for AI deep optimization",
    deepAnalysis: "DEEP ANALYSIS",
    selectGame: "Select Game",
    noGame: "No game selected",
    portBridge: "DEDICATED PORT BRIDGE",
    packetsRecovered: "RECOVERED",
    injectTime: "INJECT TIME",
    absoluteStability: "STABILITY",
    ioSync: "I/O SYNC MATRIX",
    touchInput: "Touch Input",
    serverAck: "Server ACK",
    udpLoadBalancer: "UDP LOAD BALANCER",
    fastRetransmit: "FAST-RETRANSMIT LOG",

    networkPaths: "Network Paths",
    pathsSubtitle: "15 high-speed routes · AI auto-switching",
    tapToSwitch: "Tap to force-switch",
    optimalLabel: "OPTIMAL",
    goodLabel: "GOOD",
    degradedLabel: "DEGRADED",
    offlineLabel: "OFFLINE",

    dnsSecurity: "DNS Security",
    dnsSubtitle: "DNS-over-HTTPS · ISP throttle prevention",
    activeDns: "ACTIVE DNS",
    aiDnsSwitch: "AI DNS Auto-Switching",
    aiDnsSwitchSub: "Switches to fastest DNS on congestion",
    dnsServersLabel: "DNS SERVERS",
    encrypted: "Encrypted DNS-over-HTTPS",
    standard: "Standard DNS",
    routing: "↩ Routing active",
    tapActivate: "Tap to activate",
    dnsInfo: "DNS-over-HTTPS encrypts your DNS queries, preventing ISP throttling and monitoring. QyntrixG routes all traffic through the selected secure resolver.",

    settings: "Settings",
    settingsConfig: "QyntrixG Configuration",
    optimizationSection: "OPTIMIZATION",
    systemSection: "SYSTEM",
    shizukuSection: "SHIZUKU / ROOT BRIDGE",
    aboutSection: "ABOUT",
    languageSection: "LANGUAGE",
    optimizationLevel: "Optimization Level",
    aiPathSwitching: "AI Path Switching",
    smartPathThreshold: "Smart Path Threshold",
    foregroundService: "Foreground Service",
    startOnBoot: "Start on Boot",
    notifications: "Path Switch Notifications",
    shizukuStatus: "Shizuku Status",
    shizukuGranted: "Granted",
    shizukuNotGranted: "Not Granted",
    iptablesRules: "iptables Priority Rules",
    tcControl: "TC Traffic Control",
    version: "Version",
    engine: "Engine",
    activeCommands: "Active Shizuku Commands",
    language: "App Language",
    english: "English",
    arabic: "العربية",

    popupTitle: "AI Optimizer",
    step1: "Linking stable paths...",
    step2: "Configuring Fast DNS...",
    step3: "Testing High-Speed Ports...",
    completed: "Status: COMPLETED!",
    completedSub: "Optimization successful",

    optimEco: "Eco: Passive monitoring only",
    optimBalanced: "Balanced: AI monitoring · <60ms threshold",
    optimBoost: "Boost: Active AI switching · <40ms threshold",
    optimUltra: "Ultra: Aggressive path switching · <30ms threshold",
    optimMax: "MAX: Absolute priority · All iptables rules active · tc qdisc enabled",
    active: "Active",
    htb: "HTB / wlan0",

    boostSubtitle: "GearUP Engine · AI Speed Intelligence",
    bestPathScan: "Run Best-Path Discovery",
    bestPathScanSub: "Pings all 15 paths & 5 DNS simultaneously · selects optimal",
    discoveryRunning: "DISCOVERING BEST PATH...",
    discoveryComplete: "BEST PATH SELECTED",
    gameSensing: "Game Sensing",
    gameSensingSub: "Auto-detects game traffic and enters Ultra-Background Mode",
    ghostMode: "Ghost Mode",
    ghostModeSub: "Traffic silently re-routed without interrupting gameplay",
    ghostModeActive: "Active — Zero-Interrupt Routing",
    ghostModeInactive: "Disabled — Enable Game Sensing to activate",
    dualChannel: "Dual-Channel Bridge",
    dualChannelSub: "Bridges Wi-Fi + Mobile Data via Multipath TCP for maximum stability",
    packetReorder: "Packet Re-ordering Prevention",
    packetReorderSub: "Detects and corrects out-of-order packets that cause lag spikes",
    tunnelingProtocol: "Latency Tunneling Protocol",
    tunnelingDesc: "Bypass congested ISP nodes directly to game server backbone",
    direct: "Direct Path",
    udpTunnel: "UDP Tunnel",
    tcpFallback: "TCP Fallback",
  },
  ar: {
    appName: "QyntrixG",
    dashboardTab: "الرئيسية",
    pathsTab: "المسارات",
    boostTab: "تعزيز",
    dnsTab: "DNS",
    settingsTab: "الإعدادات",

    splashGreeting: "مرحباً بك في جمهورية اللاعبين",
    splashGreetingAr: "Welcome to the Gamers Republic",
    splashSub: "ذكاء اصطناعي · تشفير DNS · مسارات متعددة",
    splashVersion: "الإصدار 2.0 فائق",
    splashBrand: "مدعوم بـ SHIZUKU · ROOT BRIDGE",
    splashInit: "تهيئة محرك الذكاء الاصطناعي...",
    splashScanSub: "تحليل 15 مساراً · 5 عُقد DNS",

    dashboard: "لوحة الشبكة",
    connectionQuality: "جودة الاتصال",
    excellent: "ممتاز",
    good: "جيد",
    fair: "مقبول",
    poor: "ضعيف",
    aiOn: "الذكاء الاصطناعي: فعّال",
    aiOff: "الذكاء الاصطناعي: متوقف",
    ping: "تأخير",
    loss: "فقدان",
    jitter: "اهتزاز",
    download: "تنزيل",
    upload: "رفع",
    startOptimizer: "بدء التحسين",
    optimizing: "جاري التحسين",
    tapToStop: "اضغط للإيقاف · الذكاء الاصطناعي يعمل",
    tapToEnable: "اضغط لتفعيل تحسين الشبكة",
    activePath: "المسار النشط",
    aiEventLog: "سجل الذكاء الاصطناعي",
    noEvents: "لا توجد أحداث. ابدأ التحسين.",
    root: "صلاحيات جذر",
    noRoot: "بدون صلاحيات",
    aiConnectionActive: "اتصال الذكاء الاصطناعي نشط",
    activeAiSub: "مراقبة 15 مساراً في الوقت الفعلي",
    waveformLabel: "موجة الشبكة المباشرة",
    runDiscovery: "اكتشاف أفضل مسار",

    // Game Engine
    addGame: "إضافة لعبة",
    addGameSub: "تحسين عميق للعبة محددة · جسر المنافذ · توجيه ذكي",
    gameLibrary: "مكتبة الألعاب",
    gameLibrarySub: "اختر لعبة للتحسين العميق بالذكاء الاصطناعي",
    deepAnalysis: "تحليل عميق",
    selectGame: "اختر اللعبة",
    noGame: "لم يتم اختيار لعبة",
    portBridge: "جسر المنافذ المخصص",
    packetsRecovered: "مُستعادة",
    injectTime: "وقت الحقن",
    absoluteStability: "ثبات مطلق",
    ioSync: "مصفوفة مزامنة الإدخال/الإخراج",
    touchInput: "إدخال اللمس",
    serverAck: "استجابة الخادم",
    udpLoadBalancer: "موازن حمل UDP",
    fastRetransmit: "سجل إعادة الإرسال السريع",

    networkPaths: "مسارات الشبكة",
    pathsSubtitle: "15 مسار فائق السرعة · تبديل ذكي تلقائي",
    tapToSwitch: "اضغط للتبديل القسري",
    optimalLabel: "مثالي",
    goodLabel: "جيد",
    degradedLabel: "ضعيف",
    offlineLabel: "غير متصل",

    dnsSecurity: "أمان DNS",
    dnsSubtitle: "DNS-over-HTTPS · منع تقييد مزود الخدمة",
    activeDns: "DNS النشط",
    aiDnsSwitch: "تبديل DNS الذكي التلقائي",
    aiDnsSwitchSub: "يتحول لأسرع DNS عند الازدحام",
    dnsServersLabel: "خوادم DNS",
    encrypted: "DNS مشفر عبر HTTPS",
    standard: "DNS عادي",
    routing: "↩ التوجيه نشط",
    tapActivate: "اضغط للتفعيل",
    dnsInfo: "يقوم DNS-over-HTTPS بتشفير استعلامات DNS الخاصة بك، مما يمنع مزود الخدمة من تقييد حركة المرور ومراقبتها.",

    settings: "الإعدادات",
    settingsConfig: "إعدادات QyntrixG",
    optimizationSection: "التحسين",
    systemSection: "النظام",
    shizukuSection: "جسر Shizuku / الجذر",
    aboutSection: "حول التطبيق",
    languageSection: "اللغة",
    optimizationLevel: "مستوى التحسين",
    aiPathSwitching: "تبديل المسارات بالذكاء الاصطناعي",
    smartPathThreshold: "عتبة التبديل الذكي",
    foregroundService: "خدمة الواجهة الأمامية",
    startOnBoot: "بدء عند التشغيل",
    notifications: "إشعارات تبديل المسار",
    shizukuStatus: "حالة Shizuku",
    shizukuGranted: "ممنوح",
    shizukuNotGranted: "غير ممنوح",
    iptablesRules: "قواعد أولوية iptables",
    tcControl: "التحكم في حركة المرور TC",
    version: "الإصدار",
    engine: "المحرك",
    activeCommands: "أوامر Shizuku النشطة",
    language: "لغة التطبيق",
    english: "English",
    arabic: "العربية",

    popupTitle: "محسّن الذكاء الاصطناعي",
    step1: "ربط المسارات المستقرة...",
    step2: "ضبط DNS السريع...",
    step3: "اختبار المنافذ عالية السرعة...",
    completed: "الحالة: اكتمل بنجاح!",
    completedSub: "تم التحسين بنجاح",

    optimEco: "موفر: مراقبة سلبية فقط",
    optimBalanced: "متوازن: مراقبة ذكية · عتبة 60ms",
    optimBoost: "تعزيز: تبديل ذكي نشط · عتبة 40ms",
    optimUltra: "فائق: تبديل عدواني · عتبة 30ms",
    optimMax: "أقصى: أولوية مطلقة · جميع قواعد iptables · tc qdisc فعّال",
    active: "نشط",
    htb: "HTB / wlan0",

    boostSubtitle: "محرك GearUP · ذكاء السرعة الاصطناعي",
    bestPathScan: "اكتشاف أفضل مسار",
    bestPathScanSub: "يختبر جميع المسارات الـ15 و5 DNS في آنٍ واحد · يختار الأمثل",
    discoveryRunning: "جارٍ اكتشاف أفضل مسار...",
    discoveryComplete: "تم اختيار أفضل مسار",
    gameSensing: "استشعار الألعاب",
    gameSensingSub: "يكتشف تلقائياً حركة الألعاب ويدخل وضع الخلفية الفائق",
    ghostMode: "وضع الشبح",
    ghostModeSub: "إعادة توجيه صامتة بدون مقاطعة الجلسة",
    ghostModeActive: "نشط — توجيه بدون مقاطعة",
    ghostModeInactive: "معطّل — فعّل استشعار الألعاب للتنشيط",
    dualChannel: "جسر القناتين",
    dualChannelSub: "يجمع Wi-Fi والبيانات الجوالة عبر Multipath TCP لأقصى استقرار",
    packetReorder: "منع إعادة ترتيب الحزم",
    packetReorderSub: "يكتشف الحزم غير المرتبة التي تسبب تقطعات اللاتينسي",
    tunnelingProtocol: "بروتوكول نفق التأخير",
    tunnelingDesc: "تجاوز عقد ISP المزدحمة مباشرة إلى backbone خادم اللعبة",
    direct: "مسار مباشر",
    udpTunnel: "نفق UDP",
    tcpFallback: "احتياطي TCP",
  },
};

export type Translations = typeof TRANSLATIONS.en;

type LanguageContextType = {
  lang: Lang;
  t: Translations;
  setLang: (lang: Lang) => void;
  isRTL: boolean;
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    AsyncStorage.getItem("qyntrix_lang").then((val) => {
      if (val === "ar" || val === "en") setLangState(val);
    });
  }, []);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    AsyncStorage.setItem("qyntrix_lang", l);
  }, []);

  return (
    <LanguageContext.Provider value={{ lang, t: TRANSLATIONS[lang], setLang, isRTL: lang === "ar" }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within LanguageProvider");
  return ctx;
}
