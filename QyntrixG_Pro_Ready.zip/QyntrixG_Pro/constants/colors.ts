const cyberpunk = {
  text: "#e8f4ff",
  tint: "#00d4ff",
  background: "#05070f",
  foreground: "#e8f4ff",
  card: "#0a1020",
  cardForeground: "#e8f4ff",
  primary: "#00d4ff",
  primaryForeground: "#05070f",
  secondary: "#8b5cf6",
  secondaryForeground: "#ffffff",
  accent: "#00ff88",
  accentForeground: "#05070f",
  muted: "#111827",
  mutedForeground: "#4b6280",
  border: "#1a2f50",
  input: "#0d1628",
  destructive: "#ff3366",
  destructiveForeground: "#ffffff",
  warning: "#ff9500",
  surface: "#0d1628",
  surfaceElevated: "#131f35",
};

const colors = {
  light: cyberpunk,
  dark: cyberpunk,
  radius: 10,
};

export default colors;
