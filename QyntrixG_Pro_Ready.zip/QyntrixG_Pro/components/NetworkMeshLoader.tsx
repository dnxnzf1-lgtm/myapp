import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";

const NODES = [
  { x: 50, y: 10 },
  { x: 10, y: 40 },
  { x: 90, y: 40 },
  { x: 30, y: 70 },
  { x: 70, y: 70 },
  { x: 50, y: 90 },
];

const CONNECTIONS = [
  [0, 1], [0, 2], [1, 3], [2, 4], [3, 5], [4, 5], [1, 4], [2, 3],
];

const SIZE = 180;

type NodeAnim = { opacity: Animated.Value; scale: Animated.Value };

export default function NetworkMeshLoader({ label }: { label?: string }) {
  const nodeAnims = useRef<NodeAnim[]>(
    NODES.map(() => ({
      opacity: new Animated.Value(0),
      scale: new Animated.Value(0.4),
    }))
  ).current;

  const lineAnims = useRef<Animated.Value[]>(
    CONNECTIONS.map(() => new Animated.Value(0))
  ).current;

  const pulseAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const nodeSeq = NODES.map((_, i) =>
      Animated.parallel([
        Animated.timing(nodeAnims[i].opacity, {
          toValue: 1,
          duration: 300,
          delay: i * 180,
          useNativeDriver: true,
        }),
        Animated.spring(nodeAnims[i].scale, {
          toValue: 1,
          delay: i * 180,
          useNativeDriver: true,
          tension: 100,
        }),
      ])
    );

    const lineSeq = CONNECTIONS.map((_, i) =>
      Animated.timing(lineAnims[i], {
        toValue: 1,
        duration: 250,
        delay: 1100 + i * 120,
        useNativeDriver: false,
      })
    );

    Animated.parallel([...nodeSeq, ...lineSeq]).start(() => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1, duration: 900, useNativeDriver: false }),
          Animated.timing(pulseAnim, { toValue: 0.3, duration: 900, useNativeDriver: false }),
        ])
      ).start();
    });
  }, [nodeAnims, lineAnims, pulseAnim]);

  const pulseColor = pulseAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["rgba(0,212,255,0.3)", "rgba(0,212,255,1)"],
  });

  return (
    <View style={styles.container}>
      <View style={[styles.canvas, { width: SIZE, height: SIZE }]}>
        {CONNECTIONS.map(([from, to], i) => {
          const fx = (NODES[from].x / 100) * SIZE;
          const fy = (NODES[from].y / 100) * SIZE;
          const tx = (NODES[to].x / 100) * SIZE;
          const ty = (NODES[to].y / 100) * SIZE;
          const len = Math.hypot(tx - fx, ty - fy);
          const angle = (Math.atan2(ty - fy, tx - fx) * 180) / Math.PI;

          return (
            <Animated.View
              key={i}
              style={{
                position: "absolute",
                left: fx,
                top: fy,
                width: len,
                height: 1.5,
                backgroundColor: pulseColor,
                opacity: lineAnims[i],
                transformOrigin: "0 50%",
                transform: [{ rotate: `${angle}deg` }],
              }}
            />
          );
        })}

        {NODES.map((node, i) => (
          <Animated.View
            key={i}
            style={[
              styles.node,
              {
                left: (node.x / 100) * SIZE - 6,
                top: (node.y / 100) * SIZE - 6,
                opacity: nodeAnims[i].opacity,
                transform: [{ scale: nodeAnims[i].scale }],
                borderColor: pulseColor,
              },
            ]}
          />
        ))}
      </View>
      {label ? <Text style={styles.label}>{label}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: "center", gap: 20 },
  canvas: { position: "relative" },
  node: {
    position: "absolute",
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: "rgba(0,212,255,0.2)",
    borderWidth: 1.5,
  },
  label: {
    color: "#00d4ff",
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 3,
    textTransform: "uppercase",
  },
});
