import { MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

const BLUE = "#00d4ff";
const VIOLET = "#8b5cf6";
const WHITE = "#e8f4ff";

export default function AnimatedHeader() {
  const colors = useColors();

  const textOpacity = useRef(new Animated.Value(1)).current;
  const iconOpacity = useRef(new Animated.Value(0)).current;
  const colorAnim = useRef(new Animated.Value(0)).current;
  const iconScale = useRef(new Animated.Value(0.8)).current;
  const iconPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(colorAnim, { toValue: 1, duration: 1000, useNativeDriver: false }),
        Animated.timing(colorAnim, { toValue: 0.5, duration: 800, useNativeDriver: false }),
        Animated.timing(colorAnim, { toValue: 0, duration: 1000, useNativeDriver: false }),
      ])
    ).start();

    const cycle = () => {
      Animated.sequence([
        Animated.delay(2200),
        Animated.parallel([
          Animated.timing(textOpacity, { toValue: 0, duration: 350, useNativeDriver: true }),
          Animated.timing(iconOpacity, { toValue: 1, duration: 350, useNativeDriver: true }),
          Animated.spring(iconScale, { toValue: 1, useNativeDriver: true, tension: 120 }),
        ]),
        Animated.delay(1100),
        Animated.parallel([
          Animated.timing(textOpacity, { toValue: 1, duration: 350, useNativeDriver: true }),
          Animated.timing(iconOpacity, { toValue: 0, duration: 350, useNativeDriver: true }),
          Animated.timing(iconScale, { toValue: 0.8, duration: 200, useNativeDriver: true }),
        ]),
      ]).start(() => cycle());
    };

    cycle();

    Animated.loop(
      Animated.sequence([
        Animated.timing(iconPulse, { toValue: 1.2, duration: 600, useNativeDriver: true }),
        Animated.timing(iconPulse, { toValue: 1, duration: 600, useNativeDriver: true }),
      ])
    ).start();
  }, [textOpacity, iconOpacity, colorAnim, iconScale, iconPulse]);

  const color = colorAnim.interpolate({
    inputRange: [0, 0.5, 1],
    outputRange: [BLUE, WHITE, VIOLET],
  });

  return (
    <View style={styles.container}>
      <Animated.Text
        style={[
          styles.appName,
          {
            color,
            opacity: textOpacity,
            textShadowColor: BLUE,
            textShadowOffset: { width: 0, height: 0 },
            textShadowRadius: 12,
          },
        ]}
      >
        QyntrixG
      </Animated.Text>

      <Animated.View
        style={[
          styles.iconWrap,
          {
            opacity: iconOpacity,
            transform: [{ scale: iconScale }],
          },
        ]}
        pointerEvents="none"
      >
        <Animated.View style={{ transform: [{ scale: iconPulse }] }}>
          <View style={[styles.iconOuter, { borderColor: `${BLUE}60` }]}>
            <View style={[styles.iconInner, { borderColor: `${VIOLET}80` }]}>
              <MaterialCommunityIcons name="network" size={28} color={BLUE} />
            </View>
          </View>
        </Animated.View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 44,
    justifyContent: "center",
  },
  appName: {
    fontSize: 30,
    fontWeight: "900",
    letterSpacing: 2,
    position: "absolute",
  },
  iconWrap: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
  },
  iconOuter: {
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },
  iconInner: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
