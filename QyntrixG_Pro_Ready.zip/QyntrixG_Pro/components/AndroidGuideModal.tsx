import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef, useState } from "react";
import { Animated, Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

const FOLDER_STRUCTURE = `QyntrixG/
├── app/
│   ├── (tabs)/
│   │   ├── index.tsx          # Dashboard
│   │   ├── paths.tsx          # 15 Paths
│   │   ├── advanced.tsx       # Boost / GearUP
│   │   ├── dns.tsx            # DNS-over-HTTPS
│   │   └── settings.tsx       # Config + Terminal
│   ├── splash.tsx             # 3-Phase Splash
│   └── _layout.tsx            # Root Layout
├── components/
│   ├── ShizukuTerminal.tsx    # Live ADB terminal
│   ├── WaveformMeter.tsx      # SVG ping waveform
│   ├── BestPathDiscovery.tsx  # 15-path probe modal
│   ├── GameLibrary.tsx        # 12-game selector
│   ├── ActiveGameCard.tsx     # Port bridge + I/O sync
│   ├── DualChannelCard.tsx    # Wi-Fi + Mobile bridge
│   └── PersistentNotification # Live banner
├── context/
│   ├── NetworkOptimizerContext # AI engine + state
│   └── LanguageContext.tsx    # AR/EN translations
├── data/
│   └── games.ts               # 12 games + CIDR + ports
├── hooks/
│   └── useColors.ts           # Cyberpunk palette
└── constants/
    └── colors.ts              # Color tokens`;

const SHIZUKU_GUIDE = [
  {
    step: "1",
    title: "Enable Wireless Debugging",
    desc: "On Android 11+: Settings → Developer Options → Wireless debugging → Enable",
    code: "adb connect <device-ip>:5555",
    icon: "wifi",
    color: "#00d4ff",
  },
  {
    step: "2",
    title: "Install Shizuku App",
    desc: "Download Shizuku from Google Play. Launch and tap 'Start via Wireless Debugging'. Grant ADB pairing.",
    code: "adb pair <ip>:<port> <code>",
    icon: "shield-key",
    color: "#8b5cf6",
  },
  {
    step: "3",
    title: "Grant Shizuku Permission",
    desc: "In QyntrixG Settings → Shizuku section → tap 'Request Permission'. Allow in the Shizuku app.",
    code: "IShizukuService.Stub.asInterface(\n  ShizukuBinderWrapper(binder)\n)",
    icon: "check-decagram",
    color: "#00ff88",
  },
  {
    step: "4",
    title: "Execute Network Commands",
    desc: "QyntrixG uses Shizuku to run privileged commands without root. Commands are injected via ADB bridge.",
    code: "ShizukuRemoteProcess.exec(\n  \"settings put global low_latency_mode 1\"\n)",
    icon: "console",
    color: "#ff9500",
  },
  {
    step: "5",
    title: "Background Persistence",
    desc: "Foreground service with high-priority notification keeps Shizuku bridge alive across app minimization.",
    code: "startForegroundService(\n  Intent(this, QyntrixGService::class)\n)",
    icon: "ghost",
    color: "#ff6b35",
  },
];

const ANDROID_COMPAT = [
  { version: "Android 8.0 (Oreo)", api: "26", status: "ok", note: "Full support · ADB only" },
  { version: "Android 9 (Pie)", api: "28", status: "ok", note: "Full support · ADB only" },
  { version: "Android 10", api: "29", status: "ok", note: "Full support · ADB only" },
  { version: "Android 11", api: "30", status: "best", note: "Wireless Debug native" },
  { version: "Android 12", api: "31", status: "best", note: "Wireless Debug + Shizuku" },
  { version: "Android 13", api: "33", status: "best", note: "Wireless Debug + Shizuku" },
  { version: "Android 14", api: "34", status: "best", note: "Full support · Recommended" },
  { version: "Android 15", api: "35", status: "best", note: "Full support · Recommended" },
];

function CodeBlock({ code }: { code: string }) {
  const colors = useColors();
  return (
    <View style={[cb.wrap, { backgroundColor: "#060d1a", borderColor: "#0d1f33" }]}>
      <Text style={[cb.code, { color: "#00ff88" }]}>{code}</Text>
    </View>
  );
}
const cb = StyleSheet.create({
  wrap: { borderRadius: 8, borderWidth: 1, padding: 10, marginTop: 6 },
  code: { fontSize: 9, fontFamily: "monospace", lineHeight: 16, letterSpacing: 0.3 },
});

type Tab = "guide" | "structure" | "compat";

export default function AndroidGuideModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const colors = useColors();
  const [tab, setTab] = useState<Tab>("guide");
  const slideAnim = useRef(new Animated.Value(700)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 250, useNativeDriver: true }),
        Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 80, friction: 13 }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
        Animated.timing(slideAnim, { toValue: 700, duration: 250, useNativeDriver: true }),
      ]).start();
    }
  }, [visible, slideAnim, fadeAnim]);

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <Animated.View style={[guide.backdrop, { opacity: fadeAnim }]}>
        <Animated.View
          style={[guide.sheet, { backgroundColor: colors.card, transform: [{ translateY: slideAnim }] }]}
        >
          <View style={[guide.handle, { backgroundColor: colors.border }]} />

          <View style={guide.headerRow}>
            <MaterialCommunityIcons name="android" size={22} color={colors.accent} />
            <View style={{ flex: 1 }}>
              <Text style={[guide.title, { color: colors.foreground }]}>Android Studio Guide</Text>
              <Text style={[guide.sub, { color: colors.mutedForeground }]}>
                QyntrixG · Shizuku Bridge · Android 8–15
              </Text>
            </View>
            <Pressable style={[guide.closeBtn, { borderColor: colors.border }]} onPress={onClose}>
              <Ionicons name="close" size={18} color={colors.mutedForeground} />
            </Pressable>
          </View>

          {/* Tabs */}
          <View style={[guide.tabs, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {(["guide", "structure", "compat"] as Tab[]).map((t) => (
              <Pressable
                key={t}
                style={[guide.tab, { backgroundColor: tab === t ? colors.primary : "transparent" }]}
                onPress={() => setTab(t)}
              >
                <Text style={[guide.tabText, { color: tab === t ? "#05070f" : colors.mutedForeground }]}>
                  {t === "guide" ? "SHIZUKU" : t === "structure" ? "STRUCTURE" : "COMPAT"}
                </Text>
              </Pressable>
            ))}
          </View>

          <ScrollView
            style={guide.scroll}
            contentContainerStyle={guide.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {tab === "guide" && (
              <View style={{ gap: 12 }}>
                <View style={[guide.infoBanner, { backgroundColor: `${colors.primary}0e`, borderColor: `${colors.primary}35` }]}>
                  <MaterialCommunityIcons name="information" size={14} color={colors.primary} />
                  <Text style={[guide.infoText, { color: colors.mutedForeground }]}>
                    QyntrixG requires ONLY Shizuku — NO root access. Wireless ADB debugging bridges all system-level commands.
                  </Text>
                </View>
                {SHIZUKU_GUIDE.map((step) => (
                  <View key={step.step} style={[guide.stepCard, { backgroundColor: colors.surface, borderColor: `${step.color}25` }]}>
                    <View style={guide.stepHeader}>
                      <View style={[guide.stepNum, { backgroundColor: step.color }]}>
                        <Text style={guide.stepNumText}>{step.step}</Text>
                      </View>
                      <MaterialCommunityIcons name={step.icon as never} size={16} color={step.color} />
                      <Text style={[guide.stepTitle, { color: colors.foreground }]}>{step.title}</Text>
                    </View>
                    <Text style={[guide.stepDesc, { color: colors.mutedForeground }]}>{step.desc}</Text>
                    <CodeBlock code={step.code} />
                  </View>
                ))}
              </View>
            )}

            {tab === "structure" && (
              <View style={{ gap: 12 }}>
                <Text style={[guide.sectionTitle, { color: colors.mutedForeground }]}>
                  PROJECT FOLDER STRUCTURE
                </Text>
                <View style={[guide.codeWrap, { backgroundColor: "#060d1a", borderColor: "#0d1f33" }]}>
                  <Text style={guide.folderCode}>{FOLDER_STRUCTURE}</Text>
                </View>
                <View style={[guide.infoBanner, { backgroundColor: `${colors.accent}0d`, borderColor: `${colors.accent}30` }]}>
                  <MaterialCommunityIcons name="check-circle" size={14} color={colors.accent} />
                  <Text style={[guide.infoText, { color: colors.mutedForeground }]}>
                    Built with Expo SDK 54 + Expo Router 6. Open in Android Studio using the bare workflow after running: expo prebuild --platform android
                  </Text>
                </View>
                <CodeBlock code={`# 1. Clone and install\ngit clone https://github.com/your-repo/QyntrixG\ncd QyntrixG && pnpm install\n\n# 2. Prebuild for Android Studio\nnpx expo prebuild --platform android\n\n# 3. Open in Android Studio\nopen android/`} />
              </View>
            )}

            {tab === "compat" && (
              <View style={{ gap: 10 }}>
                <Text style={[guide.sectionTitle, { color: colors.mutedForeground }]}>
                  ANDROID COMPATIBILITY MATRIX
                </Text>
                {ANDROID_COMPAT.map((item) => (
                  <View key={item.api} style={[guide.compatRow, { backgroundColor: colors.surface, borderColor: item.status === "best" ? `${colors.accent}30` : colors.border }]}>
                    <View style={[guide.compatIcon, { backgroundColor: item.status === "best" ? `${colors.accent}15` : `${colors.primary}10` }]}>
                      <MaterialCommunityIcons
                        name={item.status === "best" ? "star-circle" : "check-circle"}
                        size={16}
                        color={item.status === "best" ? colors.accent : colors.primary}
                      />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[guide.compatVersion, { color: colors.foreground }]}>{item.version}</Text>
                      <Text style={[guide.compatNote, { color: colors.mutedForeground }]}>{item.note}</Text>
                    </View>
                    <View style={[guide.apiBadge, { backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}35` }]}>
                      <Text style={[guide.apiText, { color: colors.primary }]}>API {item.api}</Text>
                    </View>
                  </View>
                ))}
              </View>
            )}
          </ScrollView>
        </Animated.View>
      </Animated.View>
    </Modal>
  );
}

const guide = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.82)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: "92%", paddingBottom: 32 },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginTop: 10, marginBottom: 4 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 16, paddingVertical: 12 },
  title: { fontSize: 15, fontWeight: "800" },
  sub: { fontSize: 10, marginTop: 1 },
  closeBtn: { padding: 8, borderRadius: 8, borderWidth: 1 },
  tabs: { flexDirection: "row", marginHorizontal: 16, borderRadius: 10, borderWidth: 1, padding: 3, marginBottom: 4 },
  tab: { flex: 1, paddingVertical: 7, borderRadius: 8, alignItems: "center" },
  tabText: { fontSize: 9, fontWeight: "800", letterSpacing: 1.5 },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingVertical: 12, gap: 12, paddingBottom: 32 },
  infoBanner: { flexDirection: "row", gap: 8, padding: 10, borderRadius: 8, borderWidth: 1, alignItems: "flex-start" },
  infoText: { flex: 1, fontSize: 11, lineHeight: 16 },
  stepCard: { borderRadius: 12, borderWidth: 1, padding: 12, gap: 8 },
  stepHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  stepNum: { width: 22, height: 22, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  stepNumText: { fontSize: 11, fontWeight: "900", color: "#05070f" },
  stepTitle: { fontSize: 13, fontWeight: "700", flex: 1 },
  stepDesc: { fontSize: 11, lineHeight: 16 },
  sectionTitle: { fontSize: 9, fontWeight: "700", letterSpacing: 3, textTransform: "uppercase" },
  codeWrap: { borderRadius: 10, borderWidth: 1, padding: 12 },
  folderCode: { fontSize: 9, fontFamily: "monospace", color: "#8aa0b8", lineHeight: 18, letterSpacing: 0.3 },
  compatRow: { flexDirection: "row", alignItems: "center", gap: 10, padding: 10, borderRadius: 10, borderWidth: 1 },
  compatIcon: { width: 36, height: 36, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  compatVersion: { fontSize: 12, fontWeight: "700" },
  compatNote: { fontSize: 10, marginTop: 1 },
  apiBadge: { borderWidth: 1, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 },
  apiText: { fontSize: 9, fontWeight: "700" },
});
