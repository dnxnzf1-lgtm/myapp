import React, { useEffect, useRef } from "react";
import { Animated, Dimensions, StyleSheet, View } from "react-native";

const { width, height } = Dimensions.get("window");

const COLORS = ["#00d4ff", "#8b5cf6", "#00ff88", "#00d4ff", "#8b5cf6"];

type Line = {
  anim: Animated.Value;
  x: number;
  color: string;
  width: number;
  delay: number;
  duration: number;
  opacity: number;
};

function createLines(count: number): Line[] {
  return Array.from({ length: count }, (_, i) => ({
    anim: new Animated.Value(0),
    x: Math.random() * width,
    color: COLORS[i % COLORS.length],
    width: Math.random() * 1.5 + 0.5,
    delay: Math.random() * 2000,
    duration: Math.random() * 1500 + 800,
    opacity: Math.random() * 0.5 + 0.2,
  }));
}

function DataLine({ line }: { line: Line }) {
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(line.delay),
        Animated.timing(line.anim, {
          toValue: 1,
          duration: line.duration,
          useNativeDriver: true,
        }),
        Animated.timing(line.anim, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [line]);

  const translateY = line.anim.interpolate({
    inputRange: [0, 1],
    outputRange: [-80, height + 80],
  });

  const opacity = line.anim.interpolate({
    inputRange: [0, 0.1, 0.8, 1],
    outputRange: [0, line.opacity, line.opacity, 0],
  });

  return (
    <Animated.View
      style={[
        styles.line,
        {
          left: line.x,
          width: line.width,
          backgroundColor: line.color,
          opacity,
          transform: [{ translateY }],
        },
      ]}
    />
  );
}

export default function DataFlowBackground({ lineCount = 18 }: { lineCount?: number }) {
  const linesRef = useRef<Line[]>(createLines(lineCount));

  return (
    <View style={[StyleSheet.absoluteFill, { pointerEvents: "none" }]}>
      {linesRef.current.map((line, i) => (
        <DataLine key={i} line={line} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  line: {
    position: "absolute",
    top: 0,
    height: 60,
    borderRadius: 2,
  },
});
