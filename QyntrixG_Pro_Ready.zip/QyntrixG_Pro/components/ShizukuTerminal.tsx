import { MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useColors } from "@/hooks/useColors";
import { Game } from "@/data/games";

type CmdStatus = "pending" | "running" | "done" | "error";

type ShizukuCmd = {
  id: number;
  cmd: string;
  output: string;
  execMs: number;
  category: string;
  status: CmdStatus;
};

const BASE_COMMANDS: Omit<ShizukuCmd, "id" | "status">[] = [
  { cmd: "settings put global low_latency_mode 1", output: "OK", execMs: 38, category: "SYSTEM" },
  { cmd: "settings put global wifi_sleep_policy 2", output: "OK", execMs: 24, category: "SYSTEM" },
  { cmd: "sysctl -w net.ipv4.tcp_fastopen=3", output: "net.ipv4.tcp_fastopen = 3", execMs: 22, category: "KERNEL" },
  { cmd: "sysctl -w net.core.rmem_max=16777216", output: "net.core.rmem_max = 16777216", execMs: 19, category: "KERNEL" },
  { cmd: "sysctl -w net.ipv4.tcp_no_metrics_save=1", output: "net.ipv4.tcp_no_metrics_save = 1", execMs: 21, category: "KERNEL" },
  { cmd: "tc qdisc add dev wlan0 root handle 1: htb default 10", output: "qdisc htb 1: root refcnt 2", execMs: 67, category: "TC" },
  { cmd: "tc class add dev wlan0 parent 1: classid 1:10 htb rate 100mbit ceil 100mbit", output: "class htb 1:10 added", execMs: 54, category: "TC" },
  { cmd: "iptables -t mangle -A OUTPUT -p udp --dport 10012 -j DSCP --set-dscp-class EF", output: "iptables: rule added", execMs: 48, category: "IPTABLES" },
  { cmd: "iptables -A OUTPUT -p udp -m multiport --dports 10012,17000,17500 -j MARK --set-mark 1", output: "iptables: mark rule applied", execMs: 52, category: "IPTABLES" },
  { cmd: "ip rule add fwmark 1 table 100 pref 1000", output: "rule added", execMs: 29, category: "IP" },
  { cmd: "ip route add 103.28.54.0/24 dev wlan0 metric 1 table 100", output: "route added", execMs: 35, category: "IP" },
];

function buildCommands(game: Game | null): ShizukuCmd[] {
  const extra: Omit<ShizukuCmd, "id" | "status">[] = game
    ? [
        { cmd: `ip route add ${game.serverRanges[0]} dev wlan0 metric 1`, output: "game route added", execMs: 33, category: "GAME" },
        ...game.udpPorts.slice(0, 2).map((p) => ({
          cmd: `iptables -A OUTPUT -p udp --dport ${p} -j DSCP --set-dscp-class EF`,
          output: `EF mark: port ${p}`,
          execMs: 41,
          category: "GAME",
        })),
      ]
    : [];
  return [...BASE_COMMANDS, ...extra].map((c, i) => ({ ...c, id: i + 1, status: "pending" as CmdStatus }));
}

const CAT_COLORS: Record<string, string> = {
  SYSTEM: "#8b5cf6",
  KERNEL: "#00d4ff",
  TC: "#ff9500",
  IPTABLES: "#ff3366",
  IP: "#00ff88",
  GAME: "#ff6b35",
};

function CmdRow({ cmd, isLast }: { cmd: ShizukuCmd; isLast: boolean }) {
  const colors = useColors();
  const catColor = CAT_COLORS[cmd.category] ?? colors.primary;
  const blink = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (cmd.status === "running") {
      Animated.loop(
        Animated.sequence([
          Animated.timing(blink, { toValue: 0, duration: 300, useNativeDriver: true }),
          Animated.timing(blink, { toValue: 1, duration: 300, useNativeDriver: true }),
        ])
      ).start();
    } else {
      blink.setValue(1);
    }
  }, [cmd.status, blink]);

  const shortCmd = cmd.cmd.length > 52 ? cmd.cmd.slice(0, 52) + "…" : cmd.cmd;

  return (
    <View style={[row.wrap, !isLast && { borderBottomWidth: 1, borderBottomColor: "#0d1f33" }]}>
      <View style={row.top}>
        <View style={[row.cat, { backgroundColor: `${catColor}18` }]}>
          <Text style={[row.catText, { color: catColor }]}>{cmd.category}</Text>
        </View>
        <Text style={[row.prompt, { color: "#4b6280" }]}>$ </Text>
        <Text style={[row.cmd, { color: "#c9d5e0" }]} numberOfLines={1}>{shortCmd}</Text>
      </View>
      <View style={row.statusRow}>
        {cmd.status === "pending" && (
          <Text style={[row.pending, { color: "#2a4060" }]}>· queued</Text>
        )}
        {cmd.status === "running" && (
          <View style={row.running}>
            <Animated.View style={[row.runDot, { backgroundColor: colors.primary, opacity: blink }]} />
            <Text style={[row.runText, { color: colors.primary }]}>executing…</Text>
          </View>
        )}
        {cmd.status === "done" && (
          <View style={row.done}>
            <MaterialCommunityIcons name="check-circle" size={11} color="#00ff88" />
            <Text style={[row.output, { color: "#00ff88" }]}>{cmd.output}</Text>
            <Text style={[row.ms, { color: "#2a4060" }]}>{cmd.execMs}ms</Text>
          </View>
        )}
        {cmd.status === "error" && (
          <View style={row.done}>
            <MaterialCommunityIcons name="alert-circle" size={11} color="#ff3366" />
            <Text style={[row.output, { color: "#ff3366" }]}>Error</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const row = StyleSheet.create({
  wrap: { paddingVertical: 7, paddingHorizontal: 12, gap: 3 },
  top: { flexDirection: "row", alignItems: "center", gap: 6 },
  cat: { borderRadius: 3, paddingHorizontal: 5, paddingVertical: 1 },
  catText: { fontSize: 7, fontWeight: "800", letterSpacing: 1 },
  prompt: { fontSize: 10, fontFamily: "monospace" },
  cmd: { fontSize: 10, flex: 1, fontFamily: "monospace" },
  statusRow: { paddingLeft: 40 },
  pending: { fontSize: 9, fontFamily: "monospace" },
  running: { flexDirection: "row", alignItems: "center", gap: 5 },
  runDot: { width: 5, height: 5, borderRadius: 2.5 },
  runText: { fontSize: 9, fontFamily: "monospace" },
  done: { flexDirection: "row", alignItems: "center", gap: 5 },
  output: { fontSize: 9, fontFamily: "monospace", flex: 1 },
  ms: { fontSize: 8, fontFamily: "monospace" },
});

type Props = { activeGame?: Game | null };

export default function ShizukuTerminal({ activeGame }: Props) {
  const colors = useColors();
  const [commands, setCommands] = useState<ShizukuCmd[]>(() => buildCommands(activeGame ?? null));
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);
  const [progress, setProgress] = useState(0);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const scrollRef = useRef<ScrollView>(null);
  const timeouts = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    setCommands(buildCommands(activeGame ?? null));
    setRunning(false);
    setDone(false);
    setProgress(0);
    progressAnim.setValue(0);
    timeouts.current.forEach(clearTimeout);
    timeouts.current = [];
  }, [activeGame, progressAnim]);

  const executeAll = () => {
    if (running) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    const fresh = buildCommands(activeGame ?? null);
    setCommands(fresh);
    setRunning(true);
    setDone(false);
    setProgress(0);
    progressAnim.setValue(0);

    let cumulativeDelay = 0;
    fresh.forEach((cmd, idx) => {
      const startDelay = cumulativeDelay;
      const runDuration = 400 + cmd.execMs * 5;
      cumulativeDelay += runDuration + 120;

      const t1 = setTimeout(() => {
        setCommands((prev) => prev.map((c, i) => i === idx ? { ...c, status: "running" } : c));
        scrollRef.current?.scrollToEnd({ animated: true });
      }, startDelay);

      const t2 = setTimeout(() => {
        setCommands((prev) => prev.map((c, i) => i === idx ? { ...c, status: "done" } : c));
        setProgress(idx + 1);
        Animated.timing(progressAnim, {
          toValue: (idx + 1) / fresh.length,
          duration: 200,
          useNativeDriver: false,
        }).start();
        scrollRef.current?.scrollToEnd({ animated: true });
      }, startDelay + runDuration);

      timeouts.current.push(t1, t2);
    });

    const finalDelay = cumulativeDelay + 200;
    const t3 = setTimeout(() => {
      setRunning(false);
      setDone(true);
    }, finalDelay);
    timeouts.current.push(t3);
  };

  const reset = () => {
    timeouts.current.forEach(clearTimeout);
    setCommands(buildCommands(activeGame ?? null));
    setRunning(false);
    setDone(false);
    setProgress(0);
    progressAnim.setValue(0);
  };

  const progressW = progressAnim.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });

  return (
    <View style={[term.wrap, { backgroundColor: "#060d1a", borderColor: running ? `${colors.primary}55` : done ? `${colors.accent}50` : "#0d1f33" }]}>
      {/* Terminal header */}
      <View style={[term.header, { borderBottomColor: "#0d1f33" }]}>
        <View style={term.dots}>
          <View style={[term.dot, { backgroundColor: "#ff3366" }]} />
          <View style={[term.dot, { backgroundColor: "#ff9500" }]} />
          <View style={[term.dot, { backgroundColor: "#00ff88" }]} />
        </View>
        <View style={{ flex: 1, alignItems: "center" }}>
          <Text style={term.title}>SHIZUKU TERMINAL</Text>
          <Text style={term.sub}>ADB Bridge · Wireless Debug · Android {running ? "Executing..." : done ? "All Commands OK" : "Ready"}</Text>
        </View>
        <View style={[term.statusDot, { backgroundColor: running ? colors.primary : done ? colors.accent : "#2a4060" }]} />
      </View>

      {/* Progress bar */}
      <View style={term.progressTrack}>
        <Animated.View style={[term.progressFill, {
          width: progressW,
          backgroundColor: done ? colors.accent : colors.primary,
        }]} />
      </View>

      {/* Command list */}
      <ScrollView
        ref={scrollRef}
        style={term.scroll}
        contentContainerStyle={{ paddingVertical: 4 }}
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled
      >
        {commands.map((cmd, i) => (
          <CmdRow key={cmd.id} cmd={cmd} isLast={i === commands.length - 1} />
        ))}
      </ScrollView>

      {/* Footer */}
      <View style={[term.footer, { borderTopColor: "#0d1f33" }]}>
        <Text style={term.footerText}>
          {done
            ? `✓ ${progress}/${commands.length} commands executed`
            : running
            ? `⚡ ${progress}/${commands.length} · executing...`
            : `${commands.length} commands · Android 8–15 compatible`
          }
        </Text>
        <View style={term.footerBtns}>
          {(running || done) && (
            <Pressable style={[term.btn, { backgroundColor: "#0d1f33" }]} onPress={reset}>
              <Text style={[term.btnText, { color: "#4b6280" }]}>RESET</Text>
            </Pressable>
          )}
          <Pressable
            style={[term.btn, {
              backgroundColor: running ? "#0d1f33" : done ? `${colors.accent}20` : `${colors.primary}20`,
              borderColor: running ? "#0d1f33" : done ? colors.accent : colors.primary,
            }]}
            onPress={running ? undefined : executeAll}
            disabled={running}
          >
            <MaterialCommunityIcons
              name={running ? "loading" : done ? "check-all" : "play"}
              size={13}
              color={running ? "#4b6280" : done ? colors.accent : colors.primary}
            />
            <Text style={[term.btnText, { color: running ? "#4b6280" : done ? colors.accent : colors.primary }]}>
              {running ? "RUNNING..." : done ? "COMPLETE" : "EXECUTE"}
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const term = StyleSheet.create({
  wrap: { borderRadius: 12, borderWidth: 1, overflow: "hidden" },
  header: { flexDirection: "row", alignItems: "center", padding: 10, borderBottomWidth: 1, gap: 8 },
  dots: { flexDirection: "row", gap: 5 },
  dot: { width: 9, height: 9, borderRadius: 4.5 },
  title: { fontSize: 9, fontWeight: "800", letterSpacing: 2, color: "#8aa0b8" },
  sub: { fontSize: 8, color: "#4b6280", letterSpacing: 0.5, marginTop: 1 },
  statusDot: { width: 7, height: 7, borderRadius: 3.5 },
  progressTrack: { height: 2, backgroundColor: "#0d1f33" },
  progressFill: { height: "100%", borderRadius: 1 },
  scroll: { maxHeight: 260 },
  footer: { flexDirection: "row", alignItems: "center", padding: 10, borderTopWidth: 1, gap: 8 },
  footerText: { flex: 1, fontSize: 9, color: "#4b6280", fontFamily: "monospace" },
  footerBtns: { flexDirection: "row", gap: 6 },
  btn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6, borderWidth: 1, borderColor: "#0d1f33" },
  btnText: { fontSize: 9, fontWeight: "800", letterSpacing: 1 },
});
