import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ActiveGameCard from "@/components/ActiveGameCard";
import AnimatedHeader from "@/components/AnimatedHeader";
import GameLibrary from "@/components/GameLibrary";
import OptimizationPopup from "@/components/OptimizationPopup";
import PersistentNotificationBanner from "@/components/PersistentNotificationBanner";
import StatCard from "@/components/StatCard";
import WaveformMeter from "@/components/WaveformMeter";
import { useLang } from "@/context/LanguageContext";
import { useNetworkOptimizer } from "@/context/NetworkOptimizerContext";
import { Game } from "@/data/games";
import { useColors } from "@/hooks/useColors";

function AiConnectionBadge() {
  const colors = useColors();
  const { t } = useLang();
  const pulse1 = useRef(new Animated.Value(0)).current;
  const pulse2 = useRef(new Animated.Value(0)).current;
  const innerGlow = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    const runPulse = (anim: Animated.Value, delay: number) => {
      const loop = () => {
        anim.setValue(0);
        setTimeout(() => {
          Animated.timing(anim, { toValue: 1, duration: 1600, useNativeDriver: true }).start(loop);
        }, delay);
      };
      loop();
    };
    runPulse(pulse1, 0);
    runPulse(pulse2, 800);
    Animated.loop(
      Animated.sequence([
        Animated.timing(innerGlow, { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.timing(innerGlow, { toValue: 0.6, duration: 700, useNativeDriver: true }),
      ])
    ).start();
  }, [pulse1, pulse2, innerGlow]);

  const makePulse = (anim: Animated.Value) => ({
    position: "absolute" as const,
    width: 28, height: 28, borderRadius: 14, borderWidth: 1,
    borderColor: colors.accent,
    opacity: anim.interpolate({ inputRange: [0, 1], outputRange: [0.7, 0] }),
    transform: [{ scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.5, 2.3] }) }],
  });

  return (
    <View style={[aiBadge.wrap, { backgroundColor: `${colors.accent}0d`, borderColor: `${colors.accent}30` }]}>
      <View style={aiBadge.dotWrap}>
        <Animated.View style={makePulse(pulse1)} />
        <Animated.View style={makePulse(pulse2)} />
        <Animated.View style={[aiBadge.dot, { backgroundColor: colors.accent, opacity: innerGlow }]} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[aiBadge.label, { color: colors.accent }]}>{t.aiConnectionActive}</Text>
        <Text style={[aiBadge.sub, { color: colors.mutedForeground }]}>{t.activeAiSub}</Text>
      </View>
      <MaterialCommunityIcons name="robot" size={18} color={`${colors.accent}70`} />
    </View>
  );
}
const aiBadge = StyleSheet.create({
  wrap: { flexDirection: "row", alignItems: "center", padding: 12, borderRadius: 12, borderWidth: 1, gap: 10 },
  dotWrap: { width: 28, height: 28, alignItems: "center", justifyContent: "center" },
  dot: { width: 10, height: 10, borderRadius: 5, position: "absolute" },
  label: { fontSize: 12, fontWeight: "700", letterSpacing: 0.3 },
  sub: { fontSize: 10, marginTop: 1 },
});

function QualityIndicator({ quality }: { quality: string }) {
  const colors = useColors();
  const pulse = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.38, duration: 900, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 900, useNativeDriver: true }),
      ])
    ).start();
  }, [pulse]);
  const color =
    quality === "excellent" ? colors.accent : quality === "good" ? colors.primary
    : quality === "fair" ? colors.warning : colors.destructive;
  return (
    <View style={qual.wrap}>
      <Animated.View style={[qual.outer, { backgroundColor: `${color}20`, transform: [{ scale: pulse }] }]} />
      <View style={[qual.dot, { backgroundColor: color }]} />
    </View>
  );
}
const qual = StyleSheet.create({
  wrap: { width: 32, height: 32, alignItems: "center", justifyContent: "center" },
  outer: { position: "absolute", width: 28, height: 28, borderRadius: 14 },
  dot: { width: 11, height: 11, borderRadius: 5.5 },
});

function LatencyBar({ latency, colors: c }: { latency: number; colors: ReturnType<typeof import("@/hooks/useColors").useColors> }) {
  const anim = useRef(new Animated.Value(0)).current;
  const pct = Math.min(latency / 200, 1);
  useEffect(() => {
    Animated.timing(anim, { toValue: pct, duration: 600, useNativeDriver: false }).start();
  }, [pct, anim]);
  const barColor = latency < 30 ? c.accent : latency < 60 ? c.primary : c.warning;
  const w = anim.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });
  return (
    <View style={lb.row}>
      <View style={[lb.track, { backgroundColor: c.muted }]}>
        <Animated.View style={[lb.bar, { width: w, backgroundColor: barColor }]} />
      </View>
      <Text style={[lb.val, { color: barColor }]}>{latency}ms</Text>
    </View>
  );
}
const lb = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8 },
  track: { flex: 1, height: 4, borderRadius: 2, overflow: "hidden" },
  bar: { height: "100%", borderRadius: 2 },
  val: { fontSize: 11, fontWeight: "700", minWidth: 38, textAlign: "right" },
});

function AddGameButton({ onPress }: { onPress: () => void }) {
  const colors = useColors();
  const { t } = useLang();
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 0.94, duration: 70, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 70, useNativeDriver: true }),
    ]).start();
    onPress();
  };

  return (
    <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
      <Pressable
        style={[addGame.btn, { backgroundColor: `${colors.secondary}0f`, borderColor: `${colors.secondary}45` }]}
        onPress={handlePress}
      >
        <View style={[addGame.icon, { backgroundColor: colors.secondary }]}>
          <MaterialCommunityIcons name="gamepad-variant-outline" size={20} color="#05070f" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[addGame.label, { color: colors.secondary }]}>{t.addGame}</Text>
          <Text style={[addGame.sub, { color: colors.mutedForeground }]}>{t.addGameSub}</Text>
        </View>
        <View style={[addGame.plus, { backgroundColor: `${colors.secondary}20`, borderColor: `${colors.secondary}50` }]}>
          <MaterialCommunityIcons name="plus" size={18} color={colors.secondary} />
        </View>
      </Pressable>
    </Animated.View>
  );
}
const addGame = StyleSheet.create({
  btn: { flexDirection: "row", alignItems: "center", padding: 12, borderRadius: 12, borderWidth: 1.5, borderStyle: "dashed", gap: 12 },
  icon: { width: 40, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  label: { fontSize: 13, fontWeight: "800", letterSpacing: 0.5 },
  sub: { fontSize: 10, marginTop: 1 },
  plus: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center", borderWidth: 1 },
});

function LiveDot({ color }: { color: string }) {
  const pulse = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.7, duration: 650, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 650, useNativeDriver: true }),
      ])
    ).start();
  }, [pulse]);
  return (
    <View style={ld.wrap}>
      <Animated.View style={[ld.outer, { backgroundColor: `${color}28`, transform: [{ scale: pulse }] }]} />
      <View style={[ld.dot, { backgroundColor: color }]} />
    </View>
  );
}
const ld = StyleSheet.create({
  wrap: { width: 22, height: 22, alignItems: "center", justifyContent: "center" },
  outer: { position: "absolute", width: 20, height: 20, borderRadius: 10 },
  dot: { width: 8, height: 8, borderRadius: 4 },
});

function AiLogItem({ text }: { text: string }) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(anim, { toValue: 1, duration: 280, useNativeDriver: true }).start();
  }, [anim]);
  return <Animated.Text style={[logS.item, { opacity: anim }]} numberOfLines={1}>{text}</Animated.Text>;
}
const logS = StyleSheet.create({
  item: { color: "#4b6280", fontSize: 10, letterSpacing: 0.4, marginBottom: 3, fontFamily: "monospace" },
});

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { t, isRTL } = useLang();
  const {
    isOptimizing, startOptimizing, stopOptimizing,
    ping, packetLoss, jitter, downloadSpeed, uploadSpeed,
    connectionQuality, aiLog, aiEnabled, currentPathId, paths,
    shizukuGranted, pingHistory,
    activeGame, setActiveGame, packetRecoveryCount, recoveryEvents,
    ioSyncDelta, inputLatency, serverResponse, loadBalance,
  } = useNetworkOptimizer();

  const [showPopup, setShowPopup] = useState(false);
  const [showGameLibrary, setShowGameLibrary] = useState(false);
  const [showLog, setShowLog] = useState(false);
  const btnScale = useRef(new Animated.Value(1)).current;

  const activePath = paths.find((p) => p.id === currentPathId);
  const topPad = Platform.OS === "web" ? 60 : insets.top;

  const qualityLabel =
    connectionQuality === "excellent" ? t.excellent : connectionQuality === "good" ? t.good
    : connectionQuality === "fair" ? t.fair : t.poor;

  const qualityColor =
    connectionQuality === "excellent" ? colors.accent : connectionQuality === "good" ? colors.primary
    : connectionQuality === "fair" ? colors.warning : colors.destructive;

  const handleToggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Animated.sequence([
      Animated.timing(btnScale, { toValue: 0.94, duration: 80, useNativeDriver: true }),
      Animated.timing(btnScale, { toValue: 1, duration: 80, useNativeDriver: true }),
    ]).start();
    if (isOptimizing) stopOptimizing();
    else setShowPopup(true);
  };

  const handleGameSelect = (game: Game) => {
    setShowGameLibrary(false);
    setActiveGame(game);
  };

  // Banner top offset — sits just below the system status bar
  const bannerTop = Platform.OS === "web" ? 4 : insets.top + 4;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Persistent Notification Banner — absolutely positioned overlay */}
      <View style={[styles.bannerContainer, { top: bannerTop }]} pointerEvents="none">
        <PersistentNotificationBanner />
      </View>

      <OptimizationPopup
        visible={showPopup}
        onComplete={() => { setShowPopup(false); startOptimizing(); }}
      />
      <GameLibrary
        visible={showGameLibrary}
        onClose={() => setShowGameLibrary(false)}
        onSelect={handleGameSelect}
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, {
          paddingTop: topPad + 12,
          paddingBottom: insets.bottom + 28,
        }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.headerRow, isRTL && { flexDirection: "row-reverse" }]}>
          <AnimatedHeader />
          <View style={styles.headerRight}>
            <View style={[styles.shizukuBadge, {
              borderColor: shizukuGranted ? `${colors.accent}55` : `${colors.destructive}55`,
              backgroundColor: shizukuGranted ? `${colors.accent}0f` : `${colors.destructive}0f`,
            }]}>
              <MaterialCommunityIcons name="shield-check" size={11} color={shizukuGranted ? colors.accent : colors.destructive} />
              <Text style={[styles.shizukuText, { color: shizukuGranted ? colors.accent : colors.destructive }]}>
                {shizukuGranted ? t.root : t.noRoot}
              </Text>
            </View>
            <Text style={[styles.dashLabel, { color: colors.mutedForeground }]}>{t.dashboard}</Text>
          </View>
        </View>

        {/* AI Connection Badge */}
        {isOptimizing && <AiConnectionBadge />}

        {/* Quality Banner */}
        <View style={[styles.qualBanner, { backgroundColor: colors.card, borderColor: `${qualityColor}28` }]}>
          <QualityIndicator quality={connectionQuality} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.qualLabel, { color: qualityColor }]}>{qualityLabel}</Text>
            <Text style={[styles.qualSub, { color: colors.mutedForeground }]}>
              {activePath ? `${activePath.name} · ${activePath.region}` : "—"}
            </Text>
          </View>
          <View style={styles.aiChip}>
            <View style={[styles.aiDot, { backgroundColor: aiEnabled ? colors.accent : colors.mutedForeground }]} />
            <Text style={[styles.aiLabel, { color: aiEnabled ? colors.accent : colors.mutedForeground }]}>
              {aiEnabled ? t.aiOn : t.aiOff}
            </Text>
          </View>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <StatCard label={t.ping} value={ping.toString()} unit="ms"
            color={ping < 30 ? colors.accent : ping < 60 ? colors.primary : colors.warning} />
          <View style={{ width: 8 }} />
          <StatCard label={t.loss} value={packetLoss.toFixed(1)} unit="%"
            color={packetLoss < 1 ? colors.accent : packetLoss < 2 ? colors.primary : colors.destructive} />
          <View style={{ width: 8 }} />
          <StatCard label={t.jitter} value={jitter.toString()} unit="ms" color={colors.secondary} />
        </View>

        {/* Live Waveform */}
        <WaveformMeter pingHistory={pingHistory} currentPing={ping} jitter={jitter} label={t.waveformLabel} />

        {/* Speed Row */}
        <View style={[styles.speedCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.speedItem}>
            <Ionicons name="arrow-down" size={15} color={colors.accent} />
            <Text style={[styles.speedValue, { color: colors.foreground }]}>{downloadSpeed}</Text>
            <Text style={[styles.speedUnit, { color: colors.mutedForeground }]}>Mbps {t.download}</Text>
          </View>
          <View style={[styles.speedDivider, { backgroundColor: colors.border }]} />
          <View style={styles.speedItem}>
            <Ionicons name="arrow-up" size={15} color={colors.primary} />
            <Text style={[styles.speedValue, { color: colors.foreground }]}>{uploadSpeed}</Text>
            <Text style={[styles.speedUnit, { color: colors.mutedForeground }]}>Mbps {t.upload}</Text>
          </View>
        </View>

        {/* Game Section */}
        {activeGame ? (
          <ActiveGameCard
            game={activeGame}
            packetRecoveryCount={packetRecoveryCount}
            recoveryEvents={recoveryEvents}
            ioSyncDelta={ioSyncDelta}
            inputLatency={inputLatency}
            serverResponse={serverResponse}
            loadBalance={loadBalance}
            onClear={() => setActiveGame(null)}
          />
        ) : (
          <AddGameButton onPress={() => setShowGameLibrary(true)} />
        )}

        {/* Main Toggle Button */}
        <Animated.View style={{ transform: [{ scale: btnScale }] }}>
          <Pressable
            style={[styles.toggleBtn, {
              backgroundColor: isOptimizing ? `${colors.accent}15` : `${colors.primary}15`,
              borderColor: isOptimizing ? colors.accent : colors.primary,
            }]}
            onPress={handleToggle}
          >
            <View style={[styles.btnIcon, { backgroundColor: isOptimizing ? colors.accent : colors.primary }]}>
              <MaterialCommunityIcons
                name={isOptimizing ? "stop-circle" : "play-circle"}
                size={28}
                color="#05070f"
              />
            </View>
            <View style={[styles.btnText, isRTL && { alignItems: "flex-end" }]}>
              <Text style={[styles.btnLabel, { color: isOptimizing ? colors.accent : colors.primary }]}>
                {isOptimizing ? t.optimizing : t.startOptimizer}
              </Text>
              <Text style={[styles.btnSub, { color: colors.mutedForeground }]}>
                {isOptimizing ? t.tapToStop : t.tapToEnable}
              </Text>
            </View>
            {isOptimizing && <LiveDot color={colors.accent} />}
          </Pressable>
        </Animated.View>

        {/* Active Path Card */}
        {activePath && (
          <View style={[styles.pathCard, { backgroundColor: colors.card, borderColor: `${colors.primary}22` }]}>
            <View style={[styles.pathRow, isRTL && { flexDirection: "row-reverse" }]}>
              <MaterialCommunityIcons name="routes" size={13} color={colors.primary} />
              <Text style={[styles.pathLabel, { color: colors.mutedForeground }]}>{t.activePath}</Text>
            </View>
            <View style={[styles.pathRow, isRTL && { flexDirection: "row-reverse" }]}>
              <Text style={[styles.pathName, { color: colors.foreground }]}>{activePath.name}</Text>
              <Text style={[styles.pathRegion, { color: colors.mutedForeground }]}>{activePath.region}</Text>
            </View>
            <LatencyBar latency={activePath.latency} colors={colors} />
          </View>
        )}

        {/* AI Log */}
        <Pressable
          style={[styles.logToggle, { borderColor: colors.border }, isRTL && { flexDirection: "row-reverse" }]}
          onPress={() => setShowLog((v) => !v)}
        >
          <MaterialCommunityIcons name="robot" size={13} color={colors.secondary} />
          <Text style={[styles.logToggleText, { color: colors.mutedForeground }]}>{t.aiEventLog}</Text>
          <Ionicons name={showLog ? "chevron-up" : "chevron-down"} size={13} color={colors.mutedForeground} />
        </Pressable>
        {showLog && (
          <View style={[styles.logBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {aiLog.length === 0
              ? <Text style={[styles.emptyLog, { color: colors.mutedForeground }]}>{t.noEvents}</Text>
              : aiLog.slice(0, 12).map((l, i) => <AiLogItem key={i} text={l} />)
            }
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, position: "relative" },
  bannerContainer: { position: "absolute", left: 0, right: 0, zIndex: 100 },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 11 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 2 },
  headerRight: { alignItems: "flex-end", gap: 4 },
  dashLabel: { fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase" },
  shizukuBadge: { flexDirection: "row", alignItems: "center", gap: 4, borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  shizukuText: { fontSize: 9, fontWeight: "700", letterSpacing: 1.5 },
  qualBanner: { flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 12, borderWidth: 1, gap: 10 },
  qualLabel: { fontSize: 15, fontWeight: "800", letterSpacing: 0.5 },
  qualSub: { fontSize: 10, marginTop: 1 },
  aiChip: { flexDirection: "row", alignItems: "center", gap: 5 },
  aiDot: { width: 6, height: 6, borderRadius: 3 },
  aiLabel: { fontSize: 10, fontWeight: "700", letterSpacing: 1 },
  statsRow: { flexDirection: "row" },
  speedCard: { flexDirection: "row", borderRadius: 12, borderWidth: 1, overflow: "hidden" },
  speedItem: { flex: 1, flexDirection: "row", alignItems: "center", padding: 13, gap: 7 },
  speedDivider: { width: 1 },
  speedValue: { fontSize: 20, fontWeight: "800" },
  speedUnit: { fontSize: 9, letterSpacing: 0.8, textTransform: "uppercase" },
  toggleBtn: { flexDirection: "row", alignItems: "center", padding: 16, borderRadius: 14, borderWidth: 1.5, gap: 14 },
  btnIcon: { width: 50, height: 50, borderRadius: 25, alignItems: "center", justifyContent: "center" },
  btnText: { flex: 1 },
  btnLabel: { fontSize: 14, fontWeight: "800", letterSpacing: 1.5 },
  btnSub: { fontSize: 10, marginTop: 3 },
  pathCard: { padding: 14, borderRadius: 12, borderWidth: 1, gap: 5 },
  pathRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  pathLabel: { fontSize: 9, fontWeight: "700", letterSpacing: 2, textTransform: "uppercase" },
  pathName: { fontSize: 15, fontWeight: "700", flex: 1 },
  pathRegion: { fontSize: 11 },
  logToggle: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 8, borderWidth: 1 },
  logToggleText: { flex: 1, fontSize: 12, fontWeight: "600" },
  logBox: { padding: 12, borderRadius: 8, borderWidth: 1 },
  emptyLog: { fontSize: 11, fontStyle: "italic" },
});
