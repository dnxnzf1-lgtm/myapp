import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useRef } from "react";
import { Animated, FlatList, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { NetworkPath, useNetworkOptimizer } from "@/context/NetworkOptimizerContext";
import { useLang } from "@/context/LanguageContext";
import { useColors } from "@/hooks/useColors";

function PathItem({
  path,
  isActive,
  onPress,
}: {
  path: NetworkPath;
  isActive: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  const { t } = useLang();
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const statusColor =
    path.status === "optimal" ? colors.accent
    : path.status === "good" ? colors.primary
    : path.status === "degraded" ? colors.warning
    : colors.destructive;

  const statusLabel =
    path.status === "optimal" ? t.optimalLabel
    : path.status === "good" ? t.goodLabel
    : path.status === "degraded" ? t.degradedLabel
    : t.offlineLabel;

  const pct = Math.min(path.latency / 220, 1);

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 0.97, duration: 60, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 60, useNativeDriver: true }),
    ]).start();
    onPress();
  };

  return (
    <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
      <Pressable
        style={[
          styles.card,
          {
            backgroundColor: isActive ? `${colors.primary}10` : colors.card,
            borderColor: isActive ? `${colors.primary}55` : colors.border,
          },
        ]}
        onPress={handlePress}
      >
        {isActive && <View style={[styles.activeBar, { backgroundColor: colors.primary }]} />}

        <View style={styles.cardTop}>
          <View style={styles.nameBlock}>
            <Text style={[styles.name, { color: isActive ? colors.primary : colors.foreground }]}>
              {path.name}
            </Text>
            <Text style={[styles.region, { color: colors.mutedForeground }]}>{path.region}</Text>
          </View>
          <View style={styles.rightBlock}>
            <Text style={[styles.latency, { color: statusColor }]}>{path.latency}ms</Text>
            {isActive && (
              <View style={[styles.activeBadge, { backgroundColor: `${colors.primary}18`, borderColor: `${colors.primary}50` }]}>
                <Text style={[styles.activeBadgeText, { color: colors.primary }]}>ACTIVE</Text>
              </View>
            )}
          </View>
        </View>

        <View style={[styles.track, { backgroundColor: colors.muted }]}>
          <View style={[styles.bar, { width: `${pct * 100}%`, backgroundColor: statusColor }]} />
        </View>

        <View style={styles.metaRow}>
          <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
          <Text style={[styles.statusText, { color: statusColor }]}>{statusLabel}</Text>
          <Text style={[styles.sep, { color: colors.border }]}>·</Text>
          <MaterialCommunityIcons name="package-variant" size={10} color={colors.mutedForeground} />
          <Text style={[styles.meta, { color: colors.mutedForeground }]}>{path.packetLoss.toFixed(1)}% loss</Text>
          <Text style={[styles.sep, { color: colors.border }]}>·</Text>
          <MaterialCommunityIcons name="timer-outline" size={10} color={colors.mutedForeground} />
          <Text style={[styles.meta, { color: colors.mutedForeground }]}>{path.jitter}ms jitter</Text>
        </View>
      </Pressable>
    </Animated.View>
  );
}

export default function PathsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { t, isRTL } = useLang();
  const { paths, currentPathId, switchPath } = useNetworkOptimizer();
  const topPad = Platform.OS === "web" ? 60 : insets.top;

  const optimal = paths.filter((p) => p.status === "optimal").length;
  const good = paths.filter((p) => p.status === "good").length;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 12 }, isRTL && { flexDirection: "row-reverse" }]}>
        <View>
          <Text style={[styles.title, { color: colors.primary }]}>{t.networkPaths}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{t.pathsSubtitle}</Text>
        </View>
        <View style={styles.badges}>
          <View style={[styles.badge, { backgroundColor: `${colors.accent}15`, borderColor: `${colors.accent}40` }]}>
            <Text style={[styles.badgeNum, { color: colors.accent }]}>{optimal}</Text>
            <Text style={[styles.badgeLbl, { color: colors.mutedForeground }]}>{t.optimalLabel}</Text>
          </View>
          <View style={[styles.badge, { backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}35` }]}>
            <Text style={[styles.badgeNum, { color: colors.primary }]}>{good}</Text>
            <Text style={[styles.badgeLbl, { color: colors.mutedForeground }]}>{t.goodLabel}</Text>
          </View>
        </View>
      </View>

      <View style={[styles.legend, { borderColor: colors.border }]}>
        {(["optimal", "good", "degraded"] as const).map((s) => {
          const c = s === "optimal" ? colors.accent : s === "good" ? colors.primary : colors.warning;
          const lbl = s === "optimal" ? t.optimalLabel : s === "good" ? t.goodLabel : t.degradedLabel;
          return (
            <View key={s} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: c }]} />
              <Text style={[styles.legendText, { color: colors.mutedForeground }]}>{lbl}</Text>
            </View>
          );
        })}
        <View style={{ flex: 1 }} />
        <Ionicons name="information-circle-outline" size={13} color={colors.mutedForeground} />
        <Text style={[styles.legendText, { color: colors.mutedForeground }]}>{t.tapToSwitch}</Text>
      </View>

      <FlatList
        data={paths}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <PathItem path={item} isActive={item.id === currentPathId} onPress={() => switchPath(item.id)} />
        )}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 24 }]}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 10, flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  title: { fontSize: 24, fontWeight: "900", letterSpacing: 1 },
  subtitle: { fontSize: 10, marginTop: 2, letterSpacing: 0.3 },
  badges: { flexDirection: "row", gap: 6 },
  badge: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6, alignItems: "center" },
  badgeNum: { fontSize: 18, fontWeight: "800" },
  badgeLbl: { fontSize: 8, letterSpacing: 1.5, textTransform: "uppercase" },
  legend: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 10, gap: 10, borderBottomWidth: 1 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  legendDot: { width: 6, height: 6, borderRadius: 3 },
  legendText: { fontSize: 10 },
  list: { paddingHorizontal: 16, paddingTop: 10 },
  card: { borderRadius: 12, borderWidth: 1, padding: 14, overflow: "hidden", gap: 8 },
  activeBar: { position: "absolute", left: 0, top: 0, bottom: 0, width: 3 },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  nameBlock: { flex: 1 },
  name: { fontSize: 15, fontWeight: "700" },
  region: { fontSize: 11, marginTop: 2 },
  rightBlock: { alignItems: "flex-end", gap: 4 },
  latency: { fontSize: 18, fontWeight: "800" },
  activeBadge: { borderWidth: 1, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  activeBadgeText: { fontSize: 8, fontWeight: "700", letterSpacing: 1.5 },
  track: { height: 3, borderRadius: 2, overflow: "hidden" },
  bar: { height: "100%", borderRadius: 2 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  statusDot: { width: 5, height: 5, borderRadius: 2.5 },
  statusText: { fontSize: 9, fontWeight: "700", letterSpacing: 0.8 },
  sep: { fontSize: 10 },
  meta: { fontSize: 9 },
});
