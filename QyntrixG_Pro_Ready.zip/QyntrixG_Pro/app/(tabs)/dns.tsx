import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { DnsServer, useNetworkOptimizer } from "@/context/NetworkOptimizerContext";
import { useLang } from "@/context/LanguageContext";
import { useColors } from "@/hooks/useColors";

function LatencyDots({ latency, colors }: { latency: number; colors: ReturnType<typeof import("@/hooks/useColors").useColors> }) {
  const filled = latency < 12 ? 5 : latency < 18 ? 4 : latency < 25 ? 3 : latency < 35 ? 2 : 1;
  return (
    <View style={{ flexDirection: "row", gap: 3, marginTop: 4 }}>
      {Array.from({ length: 5 }, (_, i) => (
        <View key={i} style={{ width: 5, height: 5, borderRadius: 2.5, backgroundColor: i < filled ? colors.accent : colors.muted }} />
      ))}
    </View>
  );
}

function DnsItem({ dns, isActive, onPress }: { dns: DnsServer; isActive: boolean; onPress: () => void }) {
  const colors = useColors();
  const { t } = useLang();

  return (
    <Pressable
      style={[styles.dnsCard, { backgroundColor: isActive ? `${colors.secondary}10` : colors.card, borderColor: isActive ? `${colors.secondary}55` : colors.border }]}
      onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onPress(); }}
    >
      {isActive && <View style={[styles.activeBar, { backgroundColor: colors.secondary }]} />}

      <View style={styles.dnsMain}>
        <View style={styles.dnsLeft}>
          <View style={styles.dnsTopRow}>
            <Text style={[styles.dnsName, { color: isActive ? colors.secondary : colors.foreground }]}>{dns.name}</Text>
            {dns.doh && (
              <View style={[styles.dohBadge, { backgroundColor: `${colors.accent}15`, borderColor: `${colors.accent}40` }]}>
                <MaterialCommunityIcons name="shield-lock" size={9} color={colors.accent} />
                <Text style={[styles.dohText, { color: colors.accent }]}>DoH</Text>
              </View>
            )}
            {isActive && (
              <View style={[styles.activeBadge, { backgroundColor: `${colors.secondary}18`, borderColor: `${colors.secondary}50` }]}>
                <Text style={[styles.activeBadgeText, { color: colors.secondary }]}>ACTIVE</Text>
              </View>
            )}
          </View>
          <Text style={[styles.dnsAddr, { color: colors.mutedForeground }]}>{dns.address}</Text>
        </View>
        <View style={styles.dnsRight}>
          <Text style={[styles.dnsLatency, { color: isActive ? colors.secondary : dns.latency < 15 ? colors.accent : colors.primary }]}>
            {dns.latency}ms
          </Text>
          <LatencyDots latency={dns.latency} colors={colors} />
        </View>
      </View>

      <View style={[styles.dnsMeta, { borderTopColor: colors.border }]}>
        <View style={styles.dnsMetaLeft}>
          <Ionicons name="lock-closed" size={10} color={dns.doh ? colors.accent : colors.mutedForeground} />
          <Text style={[styles.dnsMetaText, { color: dns.doh ? colors.accent : colors.mutedForeground }]}>
            {dns.doh ? t.encrypted : t.standard}
          </Text>
        </View>
        <Text style={[styles.dnsMetaText, { color: colors.mutedForeground }]}>
          {isActive ? t.routing : t.tapActivate}
        </Text>
      </View>
    </Pressable>
  );
}

export default function DnsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { t, isRTL } = useLang();
  const { dnsServers, currentDnsId, switchDns, aiEnabled, toggleAi } = useNetworkOptimizer();
  const topPad = Platform.OS === "web" ? 60 : insets.top;
  const activeDns = dnsServers.find((d) => d.id === currentDnsId);

  return (
    <ScrollView
      style={[styles.root, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingTop: topPad + 12, paddingBottom: insets.bottom + 28 }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.header, isRTL && { flexDirection: "row-reverse" }]}>
        <View>
          <Text style={[styles.title, { color: colors.secondary }]}>{t.dnsSecurity}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{t.dnsSubtitle}</Text>
        </View>
        <MaterialCommunityIcons name="shield-lock" size={32} color={`${colors.secondary}70`} />
      </View>

      {activeDns && (
        <View style={[styles.activeSummary, { backgroundColor: `${colors.secondary}0d`, borderColor: `${colors.secondary}30` }]}>
          <View>
            <Text style={[styles.activeDnsLabel, { color: colors.mutedForeground }]}>{t.activeDns}</Text>
            <Text style={[styles.activeDnsName, { color: colors.secondary }]}>{activeDns.name}</Text>
            <Text style={[styles.activeDnsAddr, { color: colors.mutedForeground }]}>{activeDns.address}</Text>
          </View>
          <View style={styles.activeDnsRight}>
            <Text style={[styles.activeDnsLatency, { color: colors.accent }]}>{activeDns.latency}ms</Text>
            {activeDns.doh && (
              <View style={[styles.dohBig, { backgroundColor: `${colors.accent}12`, borderColor: `${colors.accent}40` }]}>
                <MaterialCommunityIcons name="shield-check" size={11} color={colors.accent} />
                <Text style={[styles.dohBigText, { color: colors.accent }]}>DoH Active</Text>
              </View>
            )}
          </View>
        </View>
      )}

      <View style={[styles.toggleRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <MaterialCommunityIcons name="robot" size={18} color={aiEnabled ? colors.accent : colors.mutedForeground} />
        <View style={styles.toggleText}>
          <Text style={[styles.toggleLabel, { color: colors.foreground }]}>{t.aiDnsSwitch}</Text>
          <Text style={[styles.toggleSub, { color: colors.mutedForeground }]}>{t.aiDnsSwitchSub}</Text>
        </View>
        <Switch
          value={aiEnabled}
          onValueChange={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); toggleAi(); }}
          trackColor={{ false: colors.muted, true: `${colors.accent}55` }}
          thumbColor={aiEnabled ? colors.accent : colors.mutedForeground}
        />
      </View>

      <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>{t.dnsServersLabel}</Text>

      {dnsServers.map((dns) => (
        <DnsItem key={dns.id} dns={dns} isActive={dns.id === currentDnsId} onPress={() => switchDns(dns.id)} />
      ))}

      <View style={[styles.infoBox, { backgroundColor: colors.card, borderColor: `${colors.primary}28` }]}>
        <Ionicons name="information-circle" size={16} color={colors.primary} />
        <Text style={[styles.infoText, { color: colors.mutedForeground }]}>{t.dnsInfo}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 10 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 2 },
  title: { fontSize: 24, fontWeight: "900", letterSpacing: 1 },
  subtitle: { fontSize: 10, marginTop: 2 },
  activeSummary: { borderRadius: 12, borderWidth: 1, padding: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  activeDnsLabel: { fontSize: 9, fontWeight: "700", letterSpacing: 2 },
  activeDnsName: { fontSize: 18, fontWeight: "800", marginTop: 2 },
  activeDnsAddr: { fontSize: 11, marginTop: 1 },
  activeDnsRight: { alignItems: "flex-end", gap: 6 },
  activeDnsLatency: { fontSize: 24, fontWeight: "800" },
  dohBig: { flexDirection: "row", alignItems: "center", gap: 4, borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  dohBigText: { fontSize: 10, fontWeight: "700" },
  toggleRow: { flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 12, borderWidth: 1, gap: 12 },
  toggleText: { flex: 1 },
  toggleLabel: { fontSize: 13, fontWeight: "700" },
  toggleSub: { fontSize: 11, marginTop: 2 },
  sectionLabel: { fontSize: 9, fontWeight: "700", letterSpacing: 3, textTransform: "uppercase", marginTop: 4 },
  dnsCard: { borderRadius: 12, borderWidth: 1, overflow: "hidden" },
  activeBar: { position: "absolute", left: 0, top: 0, bottom: 0, width: 3 },
  dnsMain: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", padding: 14 },
  dnsLeft: { flex: 1 },
  dnsTopRow: { flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" },
  dnsName: { fontSize: 15, fontWeight: "700" },
  dohBadge: { flexDirection: "row", alignItems: "center", gap: 3, borderWidth: 1, borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2 },
  dohText: { fontSize: 8, fontWeight: "700", letterSpacing: 1 },
  activeBadge: { borderWidth: 1, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  activeBadgeText: { fontSize: 8, fontWeight: "700", letterSpacing: 1.5 },
  dnsAddr: { fontSize: 11, marginTop: 3 },
  dnsRight: { alignItems: "flex-end" },
  dnsLatency: { fontSize: 20, fontWeight: "800" },
  dnsMeta: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 14, paddingVertical: 8, borderTopWidth: 1 },
  dnsMetaLeft: { flexDirection: "row", alignItems: "center", gap: 4 },
  dnsMetaText: { fontSize: 10 },
  infoBox: { flexDirection: "row", gap: 10, padding: 14, borderRadius: 12, borderWidth: 1 },
  infoText: { flex: 1, fontSize: 11, lineHeight: 17 },
});
