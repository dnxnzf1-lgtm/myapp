import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BestPathDiscovery from "@/components/BestPathDiscovery";
import DualChannelCard from "@/components/DualChannelCard";
import { useLang } from "@/context/LanguageContext";
import { useNetworkOptimizer } from "@/context/NetworkOptimizerContext";
import { useColors } from "@/hooks/useColors";

const PROTOCOLS = [
  { id: "direct", icon: "lightning-bolt" },
  { id: "udp", icon: "transfer-up" },
  { id: "tcp", icon: "shield-half-full" },
];

function FeatureToggleCard({
  icon,
  accentColor,
  title,
  subtitle,
  enabled,
  onToggle,
  children,
}: {
  icon: string;
  accentColor: string;
  title: string;
  subtitle: string;
  enabled: boolean;
  onToggle: () => void;
  children?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={[card.wrap, { backgroundColor: colors.card, borderColor: enabled ? `${accentColor}40` : colors.border }]}>
      <View style={[card.glow, { backgroundColor: accentColor, opacity: enabled ? 0.75 : 0 }]} />
      <View style={card.row}>
        <View style={[card.icon, { backgroundColor: `${accentColor}18` }]}>
          <MaterialCommunityIcons name={icon as never} size={20} color={enabled ? accentColor : `${accentColor}60`} />
        </View>
        <View style={card.text}>
          <Text style={[card.title, { color: enabled ? colors.foreground : colors.mutedForeground }]}>{title}</Text>
          <Text style={[card.sub, { color: colors.mutedForeground }]}>{subtitle}</Text>
        </View>
        <Switch
          value={enabled}
          onValueChange={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onToggle(); }}
          trackColor={{ false: colors.muted, true: `${accentColor}55` }}
          thumbColor={enabled ? accentColor : colors.mutedForeground}
        />
      </View>
      {children}
    </View>
  );
}

const card = StyleSheet.create({
  wrap: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  glow: { position: "absolute", top: 0, left: 0, right: 0, height: 1.5 },
  row: { flexDirection: "row", alignItems: "center", padding: 14, gap: 12 },
  icon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  text: { flex: 1 },
  title: { fontSize: 14, fontWeight: "700" },
  sub: { fontSize: 11, marginTop: 2, lineHeight: 15 },
});

function GhostModeStatus({ active }: { active: boolean }) {
  const colors = useColors();
  const { t } = useLang();
  const glow = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (active) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(glow, { toValue: 1, duration: 1100, useNativeDriver: false }),
          Animated.timing(glow, { toValue: 0.1, duration: 1100, useNativeDriver: false }),
        ])
      ).start();
    } else {
      glow.setValue(0);
    }
  }, [active, glow]);

  const bg = glow.interpolate({
    inputRange: [0, 1],
    outputRange: [`${colors.secondary}06`, `${colors.secondary}16`],
  });

  return (
    <Animated.View style={[ghost.row, { backgroundColor: bg, borderTopColor: colors.border }]}>
      <MaterialCommunityIcons
        name={active ? "ghost" : "ghost-off"}
        size={20}
        color={active ? colors.secondary : colors.mutedForeground}
      />
      <View style={{ flex: 1 }}>
        <Text style={[ghost.label, { color: active ? colors.secondary : colors.mutedForeground }]}>
          {t.ghostMode}
        </Text>
        <Text style={[ghost.sub, { color: colors.mutedForeground }]}>
          {active ? t.ghostModeActive : t.ghostModeInactive}
        </Text>
      </View>
      {active && (
        <View style={[ghost.badge, { backgroundColor: `${colors.secondary}18`, borderColor: `${colors.secondary}50` }]}>
          <View style={[ghost.dot, { backgroundColor: colors.secondary }]} />
          <Text style={[ghost.badgeText, { color: colors.secondary }]}>LIVE</Text>
        </View>
      )}
    </Animated.View>
  );
}

const ghost = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", padding: 12, paddingHorizontal: 14, borderTopWidth: 1, gap: 10 },
  label: { fontSize: 12, fontWeight: "700" },
  sub: { fontSize: 10, marginTop: 1 },
  badge: { flexDirection: "row", alignItems: "center", gap: 4, borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  dot: { width: 5, height: 5, borderRadius: 2.5 },
  badgeText: { fontSize: 9, fontWeight: "700", letterSpacing: 1.5 },
});

function PacketOrderVisual({ enabled }: { enabled: boolean }) {
  const colors = useColors();
  const color = enabled ? colors.accent : colors.warning;
  const packets = enabled ? ["P1", "P2", "P3", "P4"] : ["P3", "P1", "P4", "P2"];
  return (
    <View style={[pkt.row, { borderTopColor: colors.border }]}>
      <View style={pkt.packets}>
        {packets.map((p, i) => (
          <View key={i} style={[pkt.packet, { backgroundColor: `${color}15`, borderColor: `${color}45` }]}>
            <Text style={[pkt.pLabel, { color }]}>{p}</Text>
          </View>
        ))}
      </View>
      <MaterialCommunityIcons name="arrow-right" size={14} color={colors.mutedForeground} />
      <MaterialCommunityIcons name={enabled ? "check-circle" : "alert-circle-outline"} size={18} color={color} />
      <Text style={[pkt.status, { color }]}>{enabled ? "ORDERED" : "DISORDERED"}</Text>
    </View>
  );
}

const pkt = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 14, paddingBottom: 12, borderTopWidth: 1 },
  packets: { flexDirection: "row", gap: 4 },
  packet: { borderWidth: 1, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 3 },
  pLabel: { fontSize: 9, fontWeight: "700" },
  status: { fontSize: 10, fontWeight: "700", letterSpacing: 1 },
});

function ProtocolSelector({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const colors = useColors();
  const { t } = useLang();
  const labels: Record<string, string> = { direct: t.direct, udp: t.udpTunnel, tcp: t.tcpFallback };
  return (
    <View style={[proto.row, { borderTopColor: colors.border }]}>
      {PROTOCOLS.map(({ id, icon }) => {
        const active = value === id;
        return (
          <Pressable
            key={id}
            style={[proto.btn, { backgroundColor: active ? `${colors.primary}18` : colors.muted, borderColor: active ? colors.primary : colors.border }]}
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onChange(id); }}
          >
            <MaterialCommunityIcons name={icon as never} size={16} color={active ? colors.primary : colors.mutedForeground} />
            <Text style={[proto.label, { color: active ? colors.primary : colors.mutedForeground }]} numberOfLines={1}>
              {labels[id]}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const proto = StyleSheet.create({
  row: { flexDirection: "row", gap: 8, padding: 12, borderTopWidth: 1 },
  btn: { flex: 1, alignItems: "center", gap: 5, padding: 10, borderRadius: 10, borderWidth: 1 },
  label: { fontSize: 9, fontWeight: "700", textAlign: "center" },
});

function StatusGrid({ items }: { items: { label: string; active: boolean; color: string }[] }) {
  const colors = useColors();
  return (
    <View style={grid.container}>
      {items.map((item, i) => (
        <View key={i} style={grid.item}>
          <View style={[grid.dot, { backgroundColor: item.active ? item.color : colors.muted }]} />
          <Text style={[grid.label, { color: item.active ? item.color : colors.mutedForeground }]}>
            {item.label}
          </Text>
        </View>
      ))}
    </View>
  );
}

const grid = StyleSheet.create({
  container: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  item: { flexDirection: "row", alignItems: "center", gap: 5, width: "30%" },
  dot: { width: 6, height: 6, borderRadius: 3 },
  label: { fontSize: 10, fontWeight: "600" },
});

export default function AdvancedScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { t, isRTL } = useLang();
  const {
    paths, switchPath,
    gameSensing, setGameSensing,
    packetReorder, setPacketReorder,
    dualChannel, setDualChannel,
    tunnelingProtocol, setTunnelingProtocol,
    downloadSpeed, isOptimizing,
  } = useNetworkOptimizer();

  const [showDiscovery, setShowDiscovery] = useState(false);
  const topPad = Platform.OS === "web" ? 60 : insets.top;
  const combined = downloadSpeed + downloadSpeed * 0.55;

  return (
    <>
      <BestPathDiscovery
        visible={showDiscovery}
        paths={paths}
        onComplete={(id) => { setShowDiscovery(false); switchPath(id); }}
      />

      <ScrollView
        style={[styles.root, { backgroundColor: colors.background }]}
        contentContainerStyle={[styles.content, { paddingTop: topPad + 12, paddingBottom: insets.bottom + 32 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.header, isRTL && { alignItems: "flex-end" }]}>
          <Text style={[styles.title, { color: colors.primary }]}>{t.boostTab}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{t.boostSubtitle}</Text>
        </View>

        {/* Best-Path Discovery button */}
        <Pressable
          style={[styles.discBtn, { backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}55` }]}
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy); setShowDiscovery(true); }}
        >
          <View style={[styles.discIcon, { backgroundColor: colors.primary }]}>
            <MaterialCommunityIcons name="radar" size={22} color="#05070f" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.discTitle, { color: colors.primary }]}>{t.bestPathScan}</Text>
            <Text style={[styles.discSub, { color: colors.mutedForeground }]}>{t.bestPathScanSub}</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.primary} />
        </Pressable>

        {/* Game Sensing + Ghost Mode */}
        <FeatureToggleCard
          icon="gamepad-variant"
          accentColor="#ff6b35"
          title={t.gameSensing}
          subtitle={t.gameSensingSub}
          enabled={gameSensing}
          onToggle={() => setGameSensing(!gameSensing)}
        >
          <GhostModeStatus active={gameSensing} />
        </FeatureToggleCard>

        {/* Dual-Channel Bridge */}
        <FeatureToggleCard
          icon="bridge"
          accentColor={colors.accent}
          title={t.dualChannel}
          subtitle={t.dualChannelSub}
          enabled={dualChannel}
          onToggle={() => setDualChannel(!dualChannel)}
        />
        {dualChannel && (
          <DualChannelCard
            enabled={dualChannel}
            wifiSpeed={downloadSpeed}
            mobileSpeed={downloadSpeed * 0.58}
            combinedThroughput={combined}
          />
        )}

        {/* Packet Re-ordering */}
        <FeatureToggleCard
          icon="sort-numeric-ascending"
          accentColor={colors.secondary}
          title={t.packetReorder}
          subtitle={t.packetReorderSub}
          enabled={packetReorder}
          onToggle={() => setPacketReorder(!packetReorder)}
        >
          <PacketOrderVisual enabled={packetReorder} />
        </FeatureToggleCard>

        {/* Latency Tunneling */}
        <View style={[styles.tunnelCard, { backgroundColor: colors.card, borderColor: `${colors.primary}28` }]}>
          <View style={[styles.tunnelGlow, { backgroundColor: colors.primary }]} />
          <View style={styles.tunnelHeader}>
            <MaterialCommunityIcons name="tunnel" size={18} color={colors.primary} />
            <Text style={[styles.tunnelTitle, { color: colors.foreground }]}>{t.tunnelingProtocol}</Text>
          </View>
          <ProtocolSelector value={tunnelingProtocol} onChange={setTunnelingProtocol} />
        </View>

        {/* GearUP Engine Summary */}
        <View style={[styles.summaryCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.summaryTitle, { color: colors.mutedForeground }]}>GEARUP ENGINE STATUS</Text>
          <StatusGrid
            items={[
              { label: "Game Sense", active: gameSensing, color: "#ff6b35" },
              { label: "Ghost Mode", active: gameSensing, color: colors.secondary },
              { label: "Dual Chan.", active: dualChannel, color: colors.accent },
              { label: "Pkt Order", active: packetReorder, color: colors.secondary },
              { label: "Tunneling", active: tunnelingProtocol !== "direct", color: colors.primary },
              { label: "Optimizer", active: isOptimizing, color: colors.accent },
            ]}
          />
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 12 },
  header: { marginBottom: 2 },
  title: { fontSize: 24, fontWeight: "900", letterSpacing: 1 },
  subtitle: { fontSize: 10, marginTop: 2 },
  discBtn: { flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 14, borderWidth: 1.5, gap: 12 },
  discIcon: { width: 46, height: 46, borderRadius: 23, alignItems: "center", justifyContent: "center" },
  discTitle: { fontSize: 14, fontWeight: "800" },
  discSub: { fontSize: 10, marginTop: 2 },
  tunnelCard: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  tunnelGlow: { height: 1.5, opacity: 0.6 },
  tunnelHeader: { flexDirection: "row", alignItems: "center", gap: 8, padding: 14, paddingBottom: 0 },
  tunnelTitle: { fontSize: 13, fontWeight: "700", flex: 1 },
  summaryCard: { borderRadius: 14, borderWidth: 1, padding: 14, gap: 12 },
  summaryTitle: { fontSize: 9, fontWeight: "700", letterSpacing: 3, textTransform: "uppercase" },
});
